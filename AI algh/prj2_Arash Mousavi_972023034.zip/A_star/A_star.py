import pandas as pd
import math
from collections import defaultdict
class Graph:
    def __init__(self, adjac_list):
        self.adjac_list = adjac_list
    def get_neighbors(self, v):
        return self.adjac_list[v]
    def h(self, n, goal, heuris_type):
     H = {}
     data=pd.read_csv('lat_long.csv', encoding = 'utf-8-sig')
     data_x=data.loc[data['NAME']== n, 'X'].values[0]
     data_y=data.loc[data['NAME']== n, 'Y'].values[0]
     goal_x=data.loc[data['NAME']== goal, 'X'].values[0]
     goal_y=data.loc[data['NAME']== goal, 'X'].values[0]
     if heuris_type=="منهتن":
         dist_to= math.sqrt(pow(data_x-goal_x,2)+pow(data_y-goal_y,2))
         H.update({n:dist_to})
     else:
        dist_to= max(abs(data_x-goal_x),abs(data_y-goal_y))
        H.update({n:dist_to})
     return H[n]
    def a_star(self, start, goal, heuris_type):
        open_list = set([start])
        closed_list = set([])
        path_till = {}
        path_till[start] = start
        path_cost_till= {}
        path_cost_till[start] = 0
        while len(open_list) > 0:
            n = None
            for v in open_list:
                if n == None or path_cost_till[v] + self.h(v, goal ,heuris_type) < path_cost_till[n] + self.h(n,goal, heuris_type):
                    n = v
            if n == None:
                print('Path does not exist!')
                return None
            if n == goal:
                reconst_path = []
                print('Cost is :', path_cost_till[goal])
                while path_till[n] != n:
                    reconst_path.append(n)
                    n = path_till[n]
                reconst_path.append(start)
                reconst_path.reverse()
                print('Path found: {}'.format(reconst_path))
                return reconst_path
            for (m, g) in self.get_neighbors(n):
                if m not in open_list and m not in closed_list:
                    path_till[m] = n
                    path_cost_till[m] =  path_cost_till[n] + g
                    open_list.add(m)
                else:
                    if path_cost_till[m] >  path_cost_till[n] + g:
                        path_till[m] = n
                        path_cost_till[m] =  path_cost_till[n] + g
                        if m in closed_list:
                            closed_list.remove(m)
                            open_list.add(m)
            open_list.remove(n)
            closed_list.add(n)
        print('Path does not exist!')
        return None
data_adj=pd.read_csv('metro(1).csv', encoding = 'utf-8-sig')
adjac_list = {data_adj.loc[k].values[0]: [] for k in range(141)}
for i in range(141):
  for j in range(1,141):
   if not pd.isnull(data_adj.loc[i].values[j]):
    adjac_list[data_adj.loc[i].values[0]].append((data_adj.iloc[j-1].values[0],data_adj.loc[i].values[j]))
# for x, y in adjac_lis.items():
#   print(x, y)
g = Graph(adjac_list)
start_station = input("Enter your value for starting station: ")
goal_station = input("Enter your value for goal station: ")
heu_type = input("Enter your Heuristic function type: ")
g.a_star(start_station,goal_station,heu_type)
# print (g.h(start_station,goal_station,heu_type))

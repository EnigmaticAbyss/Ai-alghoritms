import numpy as np
from collections import defaultdict
class Graph:
    def __init__(self):
        self.graph = defaultdict(list)  
    def addEdge(self, u, v):
        self.graph[u].append(v)
    def DFSTime(self, v, visited, goal):
        global r
        global sum
        if r != 1:
         visited.add(v)
         sum = sum + 1
         print(v, end=' ')
        if v == goal:
         r=1
         print("Finished!")
         print("Cost is :"+ str(sum) )
        if r!=1:
         for neighbour in self.graph[v]:

            if neighbour not in visited:
                self.DFSTime(neighbour, visited, goal)
    def DFS(self, v, goal):
        global r
        global sum
        r=0
        sum=0
        visited = set()
        self.DFSTime(v, visited, goal)
g = Graph()
file = open("sample.csv")
numpy_array = np.loadtxt(file, delimiter=",")
for row in range (len(numpy_array)):
  for col in range(len(numpy_array[0])):
      if col-1 >=0 and numpy_array[row][col-1]==1: 
       g.addEdge((row,col), (row,col-1))
      if row+1 < len(numpy_array) and numpy_array[row+1][col]==1: 
          g.addEdge((row,col), (row+1,col))
      if col+1 < len(numpy_array[0]) and numpy_array[row][col+1]==1: 
          g.addEdge((row,col), (row,col+1))
      if row-1 >=0 and numpy_array[row-1][col]==1: 
          g.addEdge((row,col), (row-1,col))    
g.DFS((0,0),(len(numpy_array)-1,len(numpy_array[0])-1))


import random
xo = input("which one do you want to play with?:\n 1.x\n 2.o\n ")
if xo=="2":
 print ("player o")
 player, opponent = 'x', 'o'
else:
    print ("player x")
    player, opponent = 'o', 'x'

def isMovesLeft(board) :

	for i in range(3) :
		for j in range(3) :
			if (board[i][j] == '_') :
				return True
	return False

def evaluate(b) :

	for row in range(3) :	
		if (b[row][0] == b[row][1] and b[row][1] == b[row][2]) :	
			if (b[row][0] == player) :
				return 10
			elif (b[row][0] == opponent) :
				return -10

	for col in range(3) :
	
		if (b[0][col] == b[1][col] and b[1][col] == b[2][col]) :
		
			if (b[0][col] == player) :
				return 10
			elif (b[0][col] == opponent) :
				return -10

	if (b[0][0] == b[1][1] and b[1][1] == b[2][2]) :
	
		if (b[0][0] == player) :
			return 10
		elif (b[0][0] == opponent) :
			return -10

	if (b[0][2] == b[1][1] and b[1][1] == b[2][0]) :
	
		if (b[0][2] == player) :
			return 10
		elif (b[0][2] == opponent) :
			return -10

	return 0

def minimax(board, depth, isMax,mytype,alpha,beta) :
  score = evaluate(board)
  outer=True  

  if mytype=='0':
     
   if (score == 10) :
    return score

   if (score == -10) :
    return score

   if (isMovesLeft(board) == False) :
    return 0
  else:
    if (score == 10) :
    
     return score-depth

    if (score == -10) :
   
     return score+depth

    if (isMovesLeft(board) == False) :
     return 0

  if (isMax) :	
   best = -1000

   for i in range(3) :		
    if outer== False:
        outer=True
        break
    for j in range(3) :
    
     if (board[i][j]=='_') :
     
    
      board[i][j] = player

      best = max( best, minimax(board,
            depth + 1,
            not isMax,mytype,alpha,beta) )
      alpha= max(alpha,best)
      board[i][j] = '_'
      if beta <= alpha:
       outer=False
       break
   return best


  else :
   best = 1000

   for i in range(3) :	
    if outer== False:
        outer=True
        break	
    for j in range(3) :
    
     
     if (board[i][j] == '_') :
     
    
      board[i][j] = opponent

      best = min(best, minimax(board, depth + 1, not isMax,mytype,alpha,beta))
      beta = min(beta, best)
      board[i][j] = '_'
      if beta <= alpha:
       outer=False
       break
     
   return best

def findBestMove(board,mytype) :
	bestVal = -1000
	bestMove = (-1, -1)


	for i in range(3) :	
		for j in range(3) :
		

			if (board[i][j] == '_') :
			

				board[i][j] = player

		
				moveVal = minimax(board, 0, False,mytype,-1000,1000)

			
				board[i][j] = '_'

	
				if (moveVal > bestVal) :			
					bestMove = (i, j)
					bestVal = moveVal

	print("The value of the best Move for max is :", bestVal)
	print()
	return bestMove
def findBestMoveSecond(board,mytype) :
	bestVal = +1000
	bestMove = (-1, -1)

	for i in range(3) :	
		for j in range(3) :

			if (board[i][j] == '_') :
			
			
				board[i][j] = opponent

				moveVal = minimax(board, 0,True,mytype,-1000,1000)

		
				board[i][j] = '_'

				if (moveVal < bestVal) :			
					bestMove = (i, j)
					bestVal = moveVal

	print("The value of the best Move for min is :", bestVal)
	print()
	return bestMove


def makeEmpty(board) :
	for i in range(3) :	
		for j in range(3) :
		
		
				board[i][j] = '_'	
	return board









board = [
	[ '_', '_', '_' ],
	[ '_', '_', '_' ],
	[ '_', '_', '_' ]
]


for i in range(3):
  print(board[i])
gameo=True
while gameo:
 mystate = input("Enter your game type: \n 0.player vs AI \n 1.AI vs AI \n")
 print("state:",mystate)
 
 dif = input("Choose difficulty: \n 0.Easy \n 1.Hard \n")
 print("difficulty:",dif)

 if mystate == "0" :
        

    
    firstfinder = input("Enter either one or zero: ")
    firstfinder =int(firstfinder)
    randomfinder= random.randint(0, 1)
    print("random:",randomfinder)
    while isMovesLeft(board):
        if randomfinder== firstfinder :
            x = input("Enter x for your choise: ")
            y = input("Enter y for your choise: ")
            x =int(x)
            y=int(y)
            board [x][y] = opponent
            for i in range(3):
             print(board[i])


            if evaluate(board)==10:
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-10:
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                


            bestMove = findBestMove(board,dif)
            print("The Optimal Move is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = player
            for i in range(3):
             print(board[i])
            

            if evaluate(board)==10:
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-10:
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break

                
        else:
            bestMove = findBestMove(board,dif)
            print("The Optimal Move is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = player
            for i in range(3):
             print(board[i])


            
            if evaluate(board)==10:
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-10:
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break



            x = input("Enter x for your choise: ")
            y = input("Enter y for your choise: ")
            x =int(x)
            y=int(y)
            board [x][y] = opponent
            for i in range(3):
             print(board[i])
            
            print("nomre bord:",evaluate(board))

            if evaluate(board)==10:
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-10:
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
 else:
        statos=True
        if player=="o":
             player, opponent = 'x', 'o'
             statos=False
        while isMovesLeft(board):  
            
            bestMove = findBestMove(board,dif)
            print("The Optimal Move for X is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = "x"
            for i in range(3):
             print(board[i])
            
            if evaluate(board)==10:
                print("X has won")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-10:
                print("O has won!")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break


            bestMove = findBestMoveSecond(board,dif)
            print("The Optimal Move for O is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = "o"
            for i in range(3):
             print(board[i])


            if evaluate(board)==10:
                print("X has won")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-10:
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                print("O has won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break


import random
n = input("choose the n for your \n")
n= int(n)
xo = input("which one do you want to play with?:\n 1.x\n 2.o\n ")
if xo=="2":
 print ("player o")
 player, opponent = 'x', 'o'
else:
    print ("player x")
    player, opponent = 'o', 'x'

def isMovesLeft(board) :

 for i6 in range(n) :
  for j6 in range(n) :
   if (board[i6][j6] == '_') :
    return True
 return False

def evaluate(b) :
   # print("eval \n")
   for column1 in range(n):
    count=0
    for row1 in range(n):
     if (b[row1][column1]==b[0][column1]):
      count=count+1
     else:
      break 
    if (count==n):
     if(b[0][column1]==player):
      return (n**2+1)
     elif(b[0][column1]==opponent):
      return -(n**2+1)
   for row2 in range(n):
    countar=0
    for column2 in range(n):
     if (b[row2][column2]==b[row2][0]):
      countar=countar+1
     else:
      break 
    if (countar==n):
     if(b[row2][0]==player):
      return (n**2+1)
     elif(b[row2][0]==opponent):
      return -(n**2+1)
   counters=0
   for column3 in range(n):
     if (b[0][0]==b[column3][column3]):
      counters=counters+1
     else:
      break 
   if (counters==n):
     if(b[0][0]==player):
      return (n**2+1)
     elif(b[0][0]==opponent):
      return -(n**2+1)
   counters=0
   countersa=0
   for column4 in range(n):
     if (b[n-1-column4][column4]==b[0][n-1]):
      countersa=countersa+1
     else:
      break 
   if (countersa==n):
     if(b[0][n-1]==player):
      return (n**2+1)
     elif(b[0][n-1]==opponent):
      return -(n**2+1)
   countersa=0


   return 0   

def minimax(board, depth, isMax,mytype,alpha,beta) :
  score = evaluate(board)
  outer=True  

  if mytype=='0':
     
   if (score == (n**2+1)) :
    
    return score

   if (score == -(n**2+1)) :
   
    return score

   if (isMovesLeft(board) == False) :
    return 0
  else:
    if (score == (n**2+1)) :
    #  print("d1")
     return score-depth

    if (score == -(n**2+1)) :
    #  print("d2")
     return score+depth

    if (isMovesLeft(board) == False) :
    #  print("d3")
     return 0

  if (isMax) :	
#    print("max")
   best = -1000*(n**2+1)
   outer=True
   for iw in range(n) :		
   
    if outer== False:
        outer=True
        break
    for jw in range(n) :

     if (board[iw][jw]=='_') :
     
    
      board[iw][jw] = player

      val =    minimax(board, depth + 1, not isMax,mytype,alpha,beta) 
      best = max( best,val )
      alpha= max(alpha,best)
      board[iw][jw] = '_'
      if beta <= alpha:
       outer=False
       break
   
   return best


  else :
#    print("min")
   best = 1000*(n**2+1)
   outer=True
   for ii in range(n) :	
    if outer== False:
        outer=True
        break	
    for jj in range(n) :
     # print(n+1)
     
     if (board[ii][jj] == '_') :
     
    
      board[ii][jj] = opponent
    
      val=  minimax(board, depth + 1, not isMax,mytype,alpha,beta)
      best = min(best,val )
      beta = min(beta, best)
      board[ii][jj] = '_'
      if beta <= alpha:
       outer=False
       break
     
   return best

def findBestMove(board,mytype,depth) :
 bestVal = -1000*(n**2+1)
 bestMove = (-1, -1)


 for i1 in range(n) :	
  for j1 in range(n) :
  

   if (board[i1][j1] == '_') :
    # print("Hello")    
    board[i1][j1] = player

  
    moveVal = minimax(board, depth, False,mytype,-1000*(n**2+1),1000*(n**2+1))
    # print("Hello2") 
   
    board[i1][j1] = '_'

    

    if (moveVal > bestVal) :		
    #  print("Hello3") 
     bestMove = (i1, j1)
     bestVal = moveVal
 
 print("The value of the best Move for max is :", bestVal)
 print()
 return bestMove
def findBestMoveSecond(board,mytype,depth) :
 bestVal = +1000*(n**2+1)
 bestMove = (-1, -1)

 for i2 in range(n) :	
  for j2 in range(n) :

   if (board[i2][j2] == '_') :
   
   
    board[i2][j2] = opponent

    moveVal = minimax(board, depth,True,mytype,-1000*(n**2+1),1000*(n**2+1))

  
    board[i2][j2] = '_'

    if (moveVal < bestVal) :			
     bestMove = (i2, j2)
     bestVal = moveVal

 print("The value of the best Move for min is :", bestVal)
 print()
 return bestMove


def makeEmpty(board) :
 for i3 in range(n) :	
  for j3 in range(n) :
  
  
    board[i3][j3] = '_'	
 return board





board = [['_' for x in range(n)] for y in range(n)] 


for iy in range(n):
  print(board[iy])




gameo=True
while gameo:
 mystate = input("Enter your game type: \n 0.player vs AI \n 1.AI vs AI \n")
 print("state:",mystate)
 
 dif = input("Choose difficulty: \n 0.Easy \n 1.Hard \n")
 print("difficulty:",dif)

 if mystate == "0" :
        

    
    firstfinder = input("Enter either one or zero: ")
    firstfinder =int(firstfinder)
    randomfinder= random.randint(0, 1)
    print("random:",randomfinder)
    while isMovesLeft(board):
        if randomfinder== firstfinder :
            depth=0
            x = input("Enter x for your choise: ")
            y = input("Enter y for your choise: ")
            x =int(x)
            y=int(y)
            board [x][y] = opponent
            for i11 in range(n):
             print(board[i11])
            depth=depth+1

            if evaluate(board)==(n**2+1):
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-(n**2+1):
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                


            bestMove = findBestMove(board,dif,depth)
            depth=depth+1
            print("The Optimal Move is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = player
            for i22 in range(n):
             print(board[i22])
            

            if evaluate(board)==(n**2+1):
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-(n**2+1):
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break

                
        else:
            depth=0
            bestMove = findBestMove(board,dif,depth)
            depth=depth+1
            print("The Optimal Move is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = player
            for i33 in range(n):
             print(board[i33])


            
            if evaluate(board)==(n**2+1):
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-(n**2+1):
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break



            x = input("Enter x for your choise: ")
            y = input("Enter y for your choise: ")
            x =int(x)
            y=int(y)
            board [x][y] = opponent
            for i44 in range(n):
             print(board[i44])
            depth=depth+1
            print("nomre bord:",evaluate(board))

            if evaluate(board)==(n**2+1):
                print("Oh computer has won")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-(n**2+1):
                print("You have won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
 else:
        depth=0
        statos=True
        if player=="o":
             player, opponent = 'x', 'o'
             statos=False
        while isMovesLeft(board):  
            
            bestMove = findBestMove(board,dif,depth)
            depth=depth+1
            print("The Optimal Move for X is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = "x"
            for i55 in range(n):
             print(board[i55])
            
            if evaluate(board)==(n**2+1):
                print("x has won")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-(n**2+1):
                print("O has won!")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break

            
            bestMove = findBestMoveSecond(board,dif,depth)
            depth=depth+1
            print("The Optimal Move for O is :")
            print("ROW:", bestMove[0], " COL:", bestMove[1])
            board [bestMove[0]][bestMove[1]] = "o"
            for i66 in range(n):
             print(board[i66])


            if evaluate(board)==(n**2+1):
                print("X has won")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
        
            elif evaluate(board)==-(n**2+1):
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                print("O has won!")
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
                
            if not isMovesLeft(board) and evaluate(board)==0:
                print("it's a tie")
                if statos==False:
                 player, opponent = 'o', 'x'
                 statos=True
                contin = input("if you want to continue press 1 else press 0: \n")
                if contin =="1" :
                 depth=0
                 board=makeEmpty(board)
                 break
                else:
                    gameo=False
                    break
